﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StepMocapService
{
    static class About
    {
        private static byte[] version4 = new Byte[4]{4,0,0,5};
        public static string versionDesc = "修改记录：" +
            "\n version 101 :   1.集成了手套和面部数据 2.面捕数据使用Json串转发" +
            "\n version 10101 : 1.修改手套按键，可接收远端按键信息" +
            "\n version 102 :   1.面捕数据改为用float数组发送" +
            "\n version 10201 : 1.MMAP可以随时启动" +
            "\n version 10202 : 1.可获取是否有动捕，手套，面捕数据状态, 2.去掉[MMAP可以随时启动],有一些问题"+
            "\n version 4.0.0.1 : 1.统一规范版本号"+
            "\n version 4.0.0.2 : 1.更新STEPIK算法，支持另一个模型的姿态输出, 2.一键TPose, 3.纯手模式, 4.更新注册机制, 5.手套数据只输出Global姿态" +
            "\n version 4.0.0.3 : 1.TPOSE后等10帧再去获得手套的M值， 2.支持使用加载DLL方式运行本服务, 、" +
                                "3.录制BVH改为服务录制，并直接转为FBX, 4.客户端库实现了自动重连" +
            "\n version 4.0.0.4 : 1.全录制功能, 2.BVH格式修改，向可以匹配bipe的方向修改, 3.优化了代码" +
            "\n version 4.0.0.5 : 1.机械臂，机械手相关功能， 2.添加GetOldLossyScale接口， " +
            "";

        public static int GetVersion()
        {
            int iRet = BitConverter.ToInt32(version4, 0);
            return iRet;
        }
    }
}
